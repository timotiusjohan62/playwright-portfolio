/**
 * Database-Driven API Testing Framework
 *
 * Runs automated API tests driven by a SQLite database. Each distinct TEST_CASE_NAME
 * becomes one Playwright test; each row (step) becomes an Allure step that:
 *   1. hydrates {{variables}} from state captured in earlier steps,
 *   2. signs and sends the request,
 *   3. asserts the HTTP status,
 *   4. validates the response against a dynamically generated Zod schema,
 *   5. extracts values from the response/request into state for later steps.
 */
import Database from 'better-sqlite3';
import { generateDynamicSchema } from '../utils/schemaInferrer';
import { getSignedHeaders } from '../utils/signatureGenerator';
import { test, expect, allure } from '../fixtures/base';

// ==========================================
// 0. Config
// ==========================================

const DB_PATH = 'db/TESTDATA.db';
const REQUEST_TIMEOUT_MS = 50_000;
const MAX_ATTEMPTS_SAFE_METHODS = 3; // retries only for GET/HEAD/OPTIONS, never for writes
const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);

// Previously hard-coded; override via env when needed.
const CLIENT_HEADERS = {
  'Btn-User-Id': process.env.BTN_USER_ID || 'BTN0010042',
  'Btn-Terminal-Id': process.env.BTN_TERMINAL_ID || 'PCDIMAS',
  'Btn-Terminal-Ip': process.env.BTN_TERMINAL_IP || '10.99.17.134',
};

// ==========================================
// 1. Database typings
// ==========================================

interface StepRow {
  ID: number;
  TEST_CASE_NAME: string;
  TITLE: string;
  STEP_ORDER: number;
  TYPE: string; // HTTP method
  PATH: string; // endpoint (may contain {{variables}})
  PAYLOAD: string | null; // JSON string (may contain {{variables}})
  EXTRACT_KEY: string | null; // JSON map of { "stateKey": "json.path" }
  EXPECTED_SCHEMA: string | null; // JSON schema description
  EXPECTED_STATUS: number | string;
}

// ==========================================
// 2. Database initialisation
// ==========================================

// Writable (we bump UTILS.SEQUENCE). `timeout` makes writers wait for locks instead of failing,
// and WAL lets parallel workers read while another writes.
const db = new Database(DB_PATH, { timeout: 15_000 });
// try {
//   db.pragma('journal_mode = WAL');
// } catch {
//   /* another worker may hold the lock; WAL is an optimisation, not a requirement */
// }

const selectSequence = db.prepare('SELECT SEQUENCE FROM UTILS');
const bumpSequence = db.prepare('UPDATE UTILS SET SEQUENCE = SEQUENCE + 1');

/**
 * Atomically reserves the next unique sequence number.
 * BEGIN IMMEDIATE takes the write lock up-front, so two workers can never read the same value.
 * No random fallback: a non-unique number would only move the flakiness to the server.
 */
const reserveSequence = db.transaction((): number => {
  const row = selectSequence.get() as { SEQUENCE?: number | string } | undefined;
  if (!row) throw new Error('UTILS table has no row - cannot generate a sequence number');
  const current = Number(row.SEQUENCE ?? 0);
  bumpSequence.run();
  return current;
});
const getNextSequence = (): number => reserveSequence.immediate();

// Load everything once at collection time. Using .all() (not .iterate()) avoids holding an open
// cursor/read lock for the whole run, and ORDER BY keeps test discovery identical in every worker.
const workflowNames = (
  db
    .prepare(`SELECT DISTINCT TEST_CASE_NAME FROM DATA WHERE IS_EXECUTED = '1' ORDER BY TEST_CASE_NAME ASC`)
    .all() as { TEST_CASE_NAME: string }[]
).map((r) => r.TEST_CASE_NAME);

const stepsByWorkflow = new Map<string, StepRow[]>();
const selectSteps = db.prepare('SELECT * FROM DATA WHERE TEST_CASE_NAME = ? ORDER BY STEP_ORDER ASC');
for (const name of workflowNames) {
  stepsByWorkflow.set(name, selectSteps.all(name) as StepRow[]);
}

// ==========================================
// 3. Helpers
// ==========================================

/** Extracts a nested value using dot notation (e.g. 'data.user.id'). Returns undefined if missing. */
const getNestedValue = (obj: any, path: unknown) => {
  if (path === null || path === undefined || path === '') return undefined;
  return String(path)
    .split('.')
    .reduce((acc, part) => acc?.[part], obj);
};

/** Integer-only: drops decimals, non-digits and leading zeros. */
const toJsonInteger = (value: unknown): string => {
  const digits = String(value ?? '').trim().split('.')[0].replace(/\D/g, '');
  return digits.replace(/^0+(?=\d)/, '') || '0';
};

const escapeRegExp = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

/**
 * Strips host/port prefixes from a path for HMAC signing.
 * ":7095/bp/bpjs" -> "/bp/bpjs", "/:7095/bp/bpjs" -> "/bp/bpjs"
 */
const cleanPathForSignature = (rawPath: string): string => {
  let path = rawPath.trim();
  path = path.replace(/^https?:\/\/[^/]+/, '');
  path = path.replace(/^(\/?:\d+|\d+)\//, '/');
  if (!path.startsWith('/')) path = `/${path}`;
  return path;
};

/**
 * Resolves DB endpoints with port prefixes (e.g. ":7095/bp/bpjs") into a full URL using the
 * Playwright baseURL host but the explicit port.
 */
const resolveFetchEndpoint = (rawPath: string, configBaseUrl?: string): string => {
  const path = rawPath.trim();
  if (/^https?:\/\//.test(path)) return path;

  const explicitPort = path.match(/^\/?:(\d+)/)?.[1] ?? null;
  const cleanPath = cleanPathForSignature(path);

  const base = configBaseUrl || process.env.BASE_URL || 'http://localhost:3000';
  const urlObj = new URL(base);
  if (explicitPort) urlObj.port = explicitPort;

  return new URL(cleanPath, urlObj.origin).toString();
};

/** Replaces {{key}} placeholders from state in the endpoint and payload. */
const hydrate = (
  endpoint: string,
  payload: string | null,
  state: Record<string, any>,
  sequence: number
): { endpoint: string; payload: string | null } => {
  let dynamicEndpoint = endpoint;
  let dynamicPayload = payload;

  for (const [key, value] of Object.entries(state)) {
    const k = escapeRegExp(key);

    dynamicEndpoint = dynamicEndpoint.replace(new RegExp(`\\{\\{${k}\\}\\}`, 'g'), () => String(value ?? ''));

    if (dynamicPayload) {
      // a) bare placeholder (": {{key}}") -> integer, or raw JSON for arrays/objects
      dynamicPayload = dynamicPayload.replace(
        new RegExp(`(:\\s*)\\{\\{${k}\\}\\}`, 'g'),
        (_m, prefix) =>
          prefix + (value !== null && typeof value === 'object' ? JSON.stringify(value) : toJsonInteger(value))
      );
      // b) quoted / embedded placeholder ("{{key}}") -> escaped string, zeros kept
      dynamicPayload = dynamicPayload.replace(new RegExp(`\\{\\{${k}\\}\\}`, 'g'), () =>
        JSON.stringify(String(value ?? '')).slice(1, -1)
      );
    }
  }

  // {{sequence}} uses the same reserved number as the reference header, so they always match.
  if (dynamicPayload) {
    dynamicPayload = dynamicPayload.replace(/\{\{sequence\}\}/g, String(sequence));
  }

  return { endpoint: dynamicEndpoint, payload: dynamicPayload };
};

/** Fails fast with a clear message instead of sending a request containing "{{foo}}". */
const assertNoUnresolvedPlaceholders = (step: StepRow, where: string, text: string | null) => {
  const leftover = text?.match(/\{\{\s*[\w.-]+\s*\}\}/g);
  if (leftover) {
    throw new Error(
      `Step ${step.STEP_ORDER} "${step.TITLE}": unresolved placeholder(s) in ${where}: ${[...new Set(leftover)].join(', ')}. ` +
        `An earlier step probably failed to extract them.`
    );
  }
};

// ==========================================
// 4. Playwright test suite
// ==========================================

test.describe('Database-Driven API Workflows', () => {
  test.afterAll(() => {
    if (db.open) db.close();
  });

  for (const workflowName of workflowNames) {
    const steps = stepsByWorkflow.get(workflowName) ?? [];

    test(`Executes scenario: ${workflowName}`, async ({ api, baseURL }) => {
      await allure.epic('Database-Driven API Testing');
      await allure.feature('Dynamic Workflow Execution');
      await allure.story(`Scenario: ${workflowName}`);
      await allure.severity('normal'); // 'all' is not a valid Allure severity
      await allure.owner('QA Team');
      await allure.description(
        `This test executes the API workflow defined in the database for the scenario: ${workflowName}.\n` +
          `It dynamically constructs requests, validates responses, and extracts state for subsequent steps.`
      );
      const siteUnderTest = baseURL || process.env.BASE_URL;
      if (siteUnderTest) await allure.link(siteUnderTest, 'Site under test');

      // Scale the timeout with the workload instead of a fixed 90s that retries could exceed.
      test.setTimeout(Math.max(90_000, steps.length * (REQUEST_TIMEOUT_MS + 10_000)));

      expect(steps.length, `No steps found for scenario "${workflowName}"`).toBeGreaterThan(0);

      // Per-scenario state passed between steps (tokens, generated IDs, ...).
      const testState: Record<string, any> = {};

      for (const step of steps) {
        await allure.step(`Step ${step.STEP_ORDER}: ${step.TITLE}`, async (ctx) => {
          const method = step.TYPE.toUpperCase();
          const expectedStatus = Number(step.EXPECTED_STATUS);
          await ctx.parameter('Expected status', String(expectedStatus));

          // --- Phase 1: Variable hydration ---
          const sequenceNumber = getNextSequence(); // exactly one atomic reservation per step
          const hydrated = hydrate(step.PATH, step.PAYLOAD, testState, sequenceNumber);

          assertNoUnresolvedPlaceholders(step, 'PATH', hydrated.endpoint);
          assertNoUnresolvedPlaceholders(step, 'PAYLOAD', hydrated.payload);

          let requestData: any;
          try {
            requestData = hydrated.payload ? JSON.parse(hydrated.payload) : undefined;
          } catch (e: any) {
            throw new Error(`Invalid JSON payload for "${step.TITLE}": ${e.message}\n${hydrated.payload}`);
          }

          // Sign and send the *same* serialized string. Previously the signature was computed over the
          // DB string while Playwright re-serialized the object, so whitespace/key formatting could
          // differ and cause intermittent signature failures.
          const bodyString = requestData !== undefined ? JSON.stringify(requestData) : null;
          const finalUrl = resolveFetchEndpoint(hydrated.endpoint, baseURL);
          const signedHeaders = getSignedHeaders(method, cleanPathForSignature(hydrated.endpoint), bodyString);

          const headers: Record<string, string> = {
            ...signedHeaders,
            ...(bodyString !== null ? { 'Content-Type': 'application/json' } : {}),
            'X-Btn-Key': process.env.API_KEY || '',
            'Btn-Reference-Number': `B0250${sequenceNumber}`,
            ...CLIENT_HEADERS,
          };

          await allure.attachment(
            'Request',
            JSON.stringify({ method, url: finalUrl, body: requestData }, null, 2),
            'application/json'
          );

          // --- Phase 2: Request execution ---
          // Retry only safe/idempotent methods. Retrying a POST/PUT after a timeout can create
          // duplicate records and turn a transient blip into a real, confusing failure.
          const maxAttempts = SAFE_METHODS.has(method) ? MAX_ATTEMPTS_SAFE_METHODS : 1;
          let response: Awaited<ReturnType<typeof api.call>> | undefined;

          for (let attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
              response = await api.call(method, finalUrl, {
                timeout: REQUEST_TIMEOUT_MS,
                data: bodyString ?? undefined,
                headers,
              });
              break;
            } catch (err: any) {
              if (attempt === maxAttempts) throw err;
              console.warn(`Attempt ${attempt} failed for ${finalUrl}: ${err.message}. Retrying...`);
              await new Promise((res) => setTimeout(res, 2000 * attempt));
            }
          }

          // Read the body exactly once and reuse it everywhere below.
          const rawText = await response!.text();
          let responseBody: any;
          let isJson = true;
          try {
            responseBody = JSON.parse(rawText);
          } catch {
            responseBody = rawText;
            isJson = false;
          }

          await allure.attachment(
            'Response',
            JSON.stringify({ status: response!.status(), headers: response!.headers(), body: responseBody }, null, 2),
            'application/json'
          );

          // --- Status assertion ---
          expect(
            response!.status(),
            `Step ${step.STEP_ORDER} "${step.TITLE}" ${method} ${finalUrl} returned unexpected status. Body: ${rawText.slice(0, 1000)}`
          ).toBe(expectedStatus);

          // --- Phase 3: Schema validation ---
          if (step.EXPECTED_SCHEMA) {
            expect(isJson, `Expected a JSON response for schema validation but got: ${rawText.slice(0, 500)}`).toBe(true);
            const schema = generateDynamicSchema(JSON.parse(step.EXPECTED_SCHEMA));
            const result = schema.safeParse(responseBody);
            expect(result.success, result.error?.message).toBe(true);
          }

          // --- Phase 4: State extraction ---
          if (step.EXTRACT_KEY) {
            const rules = JSON.parse(step.EXTRACT_KEY) as Record<string, string>;

            for (const [stateKey, rawPath] of Object.entries(rules)) {
              let sourceData: any = responseBody;
              let path = String(rawPath);

              if (/^(req|request)\./.test(path)) {
                sourceData = requestData;
                path = path.replace(/^(req|request)\./, '');
              } else if (/^(res|response)\./.test(path)) {
                path = path.replace(/^(res|response)\./, '');
              }

              const extracted = getNestedValue(sourceData, path);

              // A silently-undefined value only surfaces several steps later as a confusing failure.
              if (extracted === undefined) {
                throw new Error(
                  `Step ${step.STEP_ORDER} "${step.TITLE}": could not extract "${stateKey}" from path "${rawPath}".`
                );
              }
              testState[stateKey] = extracted;
            }
          }
        });
      }
    });
  }
});