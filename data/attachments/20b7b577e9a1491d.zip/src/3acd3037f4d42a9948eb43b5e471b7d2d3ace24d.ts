/**
 * Database-Driven API Testing Framework
 *
 * Runs automated API tests driven by a SQLite database.
 * It dynamically constructs requests, substitutes variables stored in state from previous steps,
 * validates HTTP status codes, verifies response payloads against dynamically generated Zod schemas,
 * and extracts data from responses to be used in subsequent requests.
 */
import Database from 'better-sqlite3';
import { generateDynamicSchema } from '../utils/schemaInferrer';
import { getSignedHeaders } from '../utils/signatureGenerator';
import { test, expect, allure } from '../fixtures/base';

// ==========================================
// Helpers
// ==========================================

/** Extract a deeply nested value using a dot-notation path (e.g. 'data.user.id'). */
const getNestedValue = (obj: any, path: any) => {
  if (!path) return undefined;
  const stringPath = typeof path === 'string' ? path : String(path);
  return stringPath.split('.').reduce((acc, part) => acc && acc[part], obj);
};

/** Integer-only: drops decimals, non-digits and leading zeros. */
const toJsonInteger = (value: unknown): string => {
  const digits = String(value ?? '').trim().split('.')[0].replace(/\D/g, '');
  return digits.replace(/^0+(?=\d)/, '') || '0';
};

/**
 * Strips port numbers/prefixes from path strings (used for HMAC signatures and URL building).
 * ":7095/bp/bpjs" -> "/bp/bpjs"
 * "/:7095/bp/bpjs" -> "/bp/bpjs"
 */
const cleanPathForSignature = (rawPath: string): string => {
  let path = rawPath.trim();
  path = path.replace(/^https?:\/\/[^\/]+/, '');
  path = path.replace(/^(\/?:\d+|\d+)\//, '/');
  if (!path.startsWith('/')) path = `/${path}`;
  return path;
};

/**
 * Resolves DB endpoints containing port prefixes (e.g. ":7095/bp/bpjs") into a full URL
 * using Playwright's baseURL host while preserving the specified port.
 */
const resolveFetchEndpoint = (rawPath: string, configBaseUrl?: string): string => {
  const path = rawPath.trim();

  if (path.startsWith('http://') || path.startsWith('https://')) {
    return path;
  }

  const portMatch = path.match(/^\/?:(\d+)/);
  const explicitPort = portMatch ? portMatch[1] : null;

  const cleanPath = cleanPathForSignature(path);

  const defaultBase = configBaseUrl || process.env.BASE_URL || 'http://localhost:3000';
  const urlObj = new URL(defaultBase);

  if (explicitPort) {
    urlObj.port = explicitPort;
  }

  return new URL(cleanPath, urlObj.origin).toString();
};

/** Generates signed headers using a clean, port-free path string. */
const getSignedHeadersForStep = (
  type: string,
  path: string,
  payload: string | null
): Record<string, string> => {
  const cleanSignaturePath = cleanPathForSignature(path);
  return getSignedHeaders(type, cleanSignaturePath, payload);
};

// ==========================================
// 1. Database Typings
// ==========================================

interface WorkflowRow {
  TEST_CASE_NAME: string;
}

interface StepRow {
  ID: number;
  TEST_CASE_NAME: string;
  TITLE: string;
  STEP_ORDER: number;
  TYPE: string;
  PATH: string;
  PAYLOAD: string | null;
  EXTRACT_KEY: string | null;
  EXPECTED_SCHEMA: string | null;
  EXPECTED_STATUS: number;
}

// ==========================================
// 2. Database Initialization
// ==========================================

// Read/write connection (we update the UTILS sequence).
const db = new Database('db/TESTDATA.db');

// WAL + busy timeout so parallel workers wait for each other instead of failing/colliding.
db.pragma('journal_mode = WAL');
db.pragma('busy_timeout = 10000');

/**
 * Atomically fetches and increments the sequence in ONE statement.
 * Safe across parallel Playwright worker processes. Returns the value BEFORE the increment.
 * (RETURNING requires SQLite 3.35+, bundled with current better-sqlite3.)
 */
const getNextSequence = (): number => {
  const row = db
    .prepare('UPDATE UTILS SET SEQUENCE = SEQUENCE + 1 RETURNING SEQUENCE - 1 AS seq')
    .get() as { seq: number };
  return row.seq;
};

// .all() so no iterator stays open on the connection.
const workflows = db
  .prepare(`SELECT DISTINCT TEST_CASE_NAME FROM DATA WHERE IS_EXECUTED = '1'`)
  .all() as WorkflowRow[];

// ==========================================
// 3. Playwright Test Suite
// ==========================================

test.describe('Database-Driven API Workflows', () => {
  // Workflows contain non-repeatable actions (payments). Never auto-retry them.
  test.describe.configure({ retries: 0 });

  for (const workflow of workflows) {
    test(`Executes scenario: ${workflow.TEST_CASE_NAME}`, async ({ api, baseURL }) => {
      await allure.epic('Database-Driven API Testing');
      await allure.feature('Dynamic Workflow Execution');
      await allure.story(`Scenario: ${workflow.TEST_CASE_NAME}`);
      await allure.severity('normal');
      await allure.owner('QA Team');
      await allure.description(`This test executes the API workflow defined in the database for the scenario: ${workflow.TEST_CASE_NAME}.
      It dynamically constructs requests, validates responses, and extracts state for subsequent steps.`);
      await allure.link(baseURL || process.env.BASE_URL || 'http://localhost:3000', 'Site under test');

      test.setTimeout(90000);

      const steps = db
        .prepare('SELECT * FROM DATA WHERE TEST_CASE_NAME = ? ORDER BY STEP_ORDER ASC')
        .all(workflow.TEST_CASE_NAME) as StepRow[];

      // In-memory state for this scenario (tokens, IDs, extracted values).
      const testState: Record<string, any> = {};

      for (const step of steps) {
        await allure.step(`Step ${step.STEP_ORDER}: ${step.TITLE}`, async (ctx) => {
          await ctx.parameter('Expected status', String(step.EXPECTED_STATUS));

          // --- Phase 1: Variable Hydration ---

          let dynamicEndpoint = step.PATH;
          let dynamicPayload = step.PAYLOAD;

          for (const [key, value] of Object.entries(testState) as [string, any][]) {
            const k = key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

            dynamicEndpoint = dynamicEndpoint.replace(
              new RegExp(`\\{\\{${k}\\}\\}`, 'g'),
              () => String(value ?? '')
            );

            if (dynamicPayload) {
              // a) bare placeholder (": {{key}}") -> integer, or raw JSON for arrays/objects
              dynamicPayload = dynamicPayload.replace(
                new RegExp(`(:\\s*)\\{\\{${k}\\}\\}`, 'g'),
                (_m, prefix) =>
                  prefix +
                  (value !== null && typeof value === 'object'
                    ? JSON.stringify(value)
                    : toJsonInteger(value))
              );

              // b) quoted / embedded placeholder ("{{key}}") -> escaped string, zeros kept
              dynamicPayload = dynamicPayload.replace(
                new RegExp(`\\{\\{${k}\\}\\}`, 'g'),
                () => JSON.stringify(String(value ?? '')).slice(1, -1)
              );
            }
          }

          // One atomic sequence value per step, reused for payload and headers.
          const sequenceNumber = getNextSequence();

          if (dynamicPayload) {
            dynamicPayload = dynamicPayload.replace(/{{sequence}}/g, String(sequenceNumber));
          }

          const headers = getSignedHeadersForStep(step.TYPE, dynamicEndpoint, dynamicPayload);
          const finalUrl = resolveFetchEndpoint(dynamicEndpoint, baseURL);

          // --- Phase 2: Request Execution ---

          let requestData: any;
          try {
            requestData = dynamicPayload ? JSON.parse(dynamicPayload) : undefined;
          } catch (e: any) {
            throw new Error(`Invalid JSON payload for "${step.TITLE}": ${e.message}\n${dynamicPayload}`);
          }

          // Only retry idempotent requests. Never re-send a POST/PUT/DELETE (e.g. payment).
          const isIdempotent = step.TYPE.toUpperCase() === 'GET';
          const maxRetries = isIdempotent ? 3 : 1;

          let response;
          let attempt = 1;

          while (attempt <= maxRetries) {
            try {
              response = await api.call(step.TYPE, finalUrl, {
                timeout: 50000,
                data: requestData,
                headers: {
                  ...headers,
                  'X-Btn-Key': process.env.API_KEY || '',
                  'Btn-Reference-Number': `B0250${sequenceNumber}`,
                  'Btn-User-Id': 'BTN0010042',
                  'Btn-Terminal-Id': 'PCDIMAS',
                  'Btn-Terminal-Ip': '10.99.17.134'
                }
              });
              break;
            } catch (err: any) {
              if (attempt === maxRetries) throw err;
              console.warn(`Attempt ${attempt} failed for ${finalUrl}: ${err.message}. Retrying...`);
              await new Promise((res) => setTimeout(res, 2000 * attempt));
              attempt++;
            }
          }

          // Parse the body ONCE and reuse it everywhere below.
          const rawText = await response!.text();
          let responseBody: any;
          try {
            responseBody = JSON.parse(rawText);
          } catch {
            responseBody = rawText;
          }

          // Base assertion: HTTP status
          expect(
            response!.status(),
            `Unexpected status on "${step.TITLE}"\nURL: ${finalUrl}\nBody: ${
              typeof responseBody === 'string' ? responseBody : JSON.stringify(responseBody, null, 2)
            }`
          ).toBe(step.EXPECTED_STATUS);

          // --- Phase 3: Schema Validation ---

          if (step.EXPECTED_SCHEMA) {
            const InferredSchema = generateDynamicSchema(JSON.parse(step.EXPECTED_SCHEMA));
            const validationResult = InferredSchema.safeParse(responseBody);

            expect(
              validationResult.success,
              `Schema mismatch on "${step.TITLE}"\n${validationResult.error?.message}\nBody: ${
                typeof responseBody === 'string' ? responseBody : JSON.stringify(responseBody, null, 2)
              }`
            ).toBe(true);
          }

          // --- Phase 4: State Extraction ---

          if (step.EXTRACT_KEY) {
            const rules = JSON.parse(step.EXTRACT_KEY);

            for (const [stateKey, responsePath] of Object.entries(rules)) {
              let sourceData: any = responseBody;
              let path = responsePath as string;

              if (path.startsWith('req.') || path.startsWith('request.')) {
                sourceData = requestData;
                path = path.replace(/^(req|request)\./, '');
              } else if (path.startsWith('res.') || path.startsWith('response.')) {
                path = path.replace(/^(res|response)\./, '');
              }

              testState[stateKey] = getNestedValue(sourceData, path);
            }
          }
        });
      }
    });
  }
});